import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile-tech-section',
  templateUrl: './mobile-tech-section.component.html',
  styleUrls: ['./mobile-tech-section.component.scss']
})
export class MobileTechSectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
