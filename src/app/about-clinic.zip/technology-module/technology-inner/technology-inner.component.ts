import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technology-inner',
  templateUrl: './technology-inner.component.html',
  styleUrls: ['./technology-inner.component.scss']
})
export class TechnologyInnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
