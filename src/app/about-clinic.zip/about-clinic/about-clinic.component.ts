import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-clinic',
  templateUrl: './about-clinic.component.html',
  styleUrls: ['./about-clinic.component.scss']
})
export class AboutClinicComponent implements OnInit {
  image1="assets/images/clinic/dumy-clinic.jpg";
  image2="assets/images/homeclnic.webp";
  defaultImage = "assets/images/service/default-image.jpg";

  constructor() { }

  ngOnInit(): void {
  }

}
