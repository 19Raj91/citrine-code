import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-doctor',
  templateUrl: './about-doctor.component.html',
  styleUrls: ['./about-doctor.component.scss']
})
export class AboutDoctorComponent implements OnInit {
  image1="assets/images/aboutpage-doctor-bg.webp";
  defaultImage = "assets/images/service/default-image.jpg";

  constructor() { }

  ngOnInit(): void {
  }

}
