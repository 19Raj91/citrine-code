import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desktop-about-choose-dr',
  templateUrl: './desktop-about-choose-dr.component.html',
  styleUrls: ['./desktop-about-choose-dr.component.scss']
})
export class DesktopAboutChooseDrComponent implements OnInit {
  image1="assets/images/choose-dr.jpg";
  constructor() { }

  ngOnInit(): void {
  }

}
