import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demoscroll',
  templateUrl: './demoscroll.component.html',
  styleUrls: ['./demoscroll.component.scss']
})
export class DemoscrollComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
