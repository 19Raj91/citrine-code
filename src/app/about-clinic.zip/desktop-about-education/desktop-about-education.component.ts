import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desktop-about-education',
  templateUrl: './desktop-about-education.component.html',
  styleUrls: ['./desktop-about-education.component.scss']
})
export class DesktopAboutEducationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
