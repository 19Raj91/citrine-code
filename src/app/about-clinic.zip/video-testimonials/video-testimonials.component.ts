import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-testimonials',
  templateUrl: './video-testimonials.component.html',
  styleUrls: ['./video-testimonials.component.scss']
})
export class VideoTestimonialsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
