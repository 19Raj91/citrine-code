import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile-abouteducation',
  templateUrl: './mobile-abouteducation.component.html',
  styleUrls: ['./mobile-abouteducation.component.scss']
})
export class MobileAbouteducationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
