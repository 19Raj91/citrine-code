import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LhrComponent } from './lhr/lhr.component';
import { HairComponent } from './hair/hair.component';



@NgModule({
  declarations: [
    LhrComponent,
    HairComponent
  ],
  imports: [
    CommonModule
  ]
})
export class LpModule { }
