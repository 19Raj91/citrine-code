import { Component, HostListener, OnInit } from '@angular/core';

@Component({
  selector: 'app-lhr',
  templateUrl: './lhr.component.html',
  styleUrls: ['./lhr.component.scss']
})
export class LhrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  navFixed: boolean = false;
  private scrollOffset: number = 70;

  @HostListener('window:scroll')
  onWindowScroll() {
    this.navFixed = (window.pageYOffset
      || document.documentElement.scrollTop
      || document.body.scrollTop || 0
    ) > this.scrollOffset;
  }


  classCommonForm = false;

  public toggleField() {
    // this.classToggled = !this.classToggled;  
     this.classCommonForm = true;  
  }
  public hidemodale(){
    this.classCommonForm = false;  
  }

}
