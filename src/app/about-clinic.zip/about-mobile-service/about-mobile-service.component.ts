import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-mobile-service',
  templateUrl: './about-mobile-service.component.html',
  styleUrls: ['./about-mobile-service.component.scss']
})
export class AboutMobileServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  image1="assets/images/mobile-dermafiller.jpg";
  image2="assets/images/mobile-laser-hair.jpg";
  image3="assets/images/mobile-laser-toning.jpg";
  image4="assets/images/mobile-growth-factor-concerntrate-.jpg";
  image5="assets/images/mobile-laser-hair-reduction.jpg";
  image6="assets/images/mobile-medical-dermatology-.jpg";
 

}
