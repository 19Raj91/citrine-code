import { Component, OnDestroy, OnInit, VERSION } from '@angular/core';
import { DesignUtilityService } from '../design-utility.service';
// import { Component, VERSION } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit , OnDestroy {
  name = 'Angular ' + VERSION.major;

  // image1="assets/images/home-web-banner.webp";
  image2="assets/images/homeclnic.webp";
  image3="assets/images/home-doctor-bg.webp";
  image4="assets/images/nsoi.webp";
  image5="assets/images/CDSI.webp";
  image6="assets/images/ISD.webp";
  image7="assets/images/IADVL.webp";
  image8="assets/images/home-dermafiller.webp";
  image9="assets/images/lasertoning.webp";
  image10="assets/images/acne-scar.webp";
  image11="assets/images/laser-hair.webp";
  image12="assets/images/growthfactor.webp";
  image13="assets/images/combind-logo.webp";
  image14="assets/images/medical-dermat.webp";
  image15="assets/images/hydrafacial.webp";

  // imagehide: string;

  imagedisplay: boolean = true;
  clickEvent() {
    // this.imagedisplay = !this.imagedisplay;  
  }

  constructor( private _designUtility:DesignUtilityService) { 
    this.imagedisplay = false;  
    setTimeout(() => {
    //  this.imagedisplay = "changed";
     this.imagedisplay = true;
    }, 3000);
  }

  ngOnInit(): void {
    this._designUtility.fix_navbar_header.next(true);
  }

  ngOnDestroy(): void {
    this._designUtility.fix_navbar_header.next(false);
  }
}
